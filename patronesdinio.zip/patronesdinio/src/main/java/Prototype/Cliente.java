/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Prototype;

/**
 *
 * @author anton
 */
public class Cliente {
    public static void main(String[] args){
        
    Bicicleta bici= new BicicletaModificada();  
    bici.setColor("rojo");
    bici.setRin(22);
    System.out.print(bici.verBicicleta());
    
    
}
}
