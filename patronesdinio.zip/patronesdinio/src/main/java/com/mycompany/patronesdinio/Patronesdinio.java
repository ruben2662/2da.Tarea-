/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.patronesdinio;

/**
 *
 * @author anton
 */
public class Patronesdinio {

    public static void main(String[] args) {
     
    }
}
