/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Prototype;

/**
 *
 * @author anton
 */
public class BicicletaModificada extends Bicicleta {

    @Override
    public String verBicicleta() {
       return ("La bicicleta es de color"+this.getColor()+"El numero de rin es"+this.toString());
    }
    
}
