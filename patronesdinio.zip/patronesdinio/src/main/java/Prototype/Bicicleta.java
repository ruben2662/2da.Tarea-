/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Prototype;

/**
 *
 * @author anton
 */
public abstract class Bicicleta implements Cloneable {
    
    private String color;
    private int rin;
    
    /**
     *
     * @return
     * @throws CloneNotSupportedException
     */
    @Override
     public Bicicleta clone() throws CloneNotSupportedException{
         
        return(Bicicleta)super.clone();    
     }
     public abstract String verBicicleta();

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getRin() {
        return rin;
    }

    public void setRin(int rin) {
        this.rin = rin;
    }
     
}
